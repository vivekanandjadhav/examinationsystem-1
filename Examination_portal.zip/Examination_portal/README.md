# Suitewise-Exam-Portal
Designing and Developement of Exam Portal In Python using django framework for backend and Bootrap Framework for frontend.
Package           Version
----------------- -------
asgiref           3.7.2
Django            5.0
pdf2image         1.16.3
Pillow            10.1.0
pip               24.0
PyMuPDF           1.23.8
PyMuPDFb          1.23.7
setuptools        63.2.0
six               1.16.0
sqlparse          0.4.4
typing_extensions 4.9.0
tzdata            2023.3