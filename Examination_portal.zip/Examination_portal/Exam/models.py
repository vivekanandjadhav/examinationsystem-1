
# Create your models here.
# models.py
from Superuser.models import Quiz
from django.db import models
from django.contrib.auth.models import User

def default_options():
    return {}

class UserExamResult(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE)
    score = models.IntegerField()
    total_questions = models.IntegerField()
    exam_code = models.CharField(max_length=10)
    exam_title = models.CharField(max_length=100)
    #selected_options = models.JSONField()  # Field to store the selected options
    selected_options = models.JSONField(default=default_options) 
    submitted_at = models.DateTimeField()  # Field to store the submission timestamp

    def __str__(self):
        return f"{self.user.username}'s Result for {self.exam_title}"