from django.contrib import admin
from django.urls import path, include
from django.contrib.auth.views import PasswordResetView, PasswordResetDoneView, PasswordResetConfirmView, PasswordResetCompleteView
from django.urls import reverse_lazy
from . import views
from .views import quiz_view, exam_results, submit_exam

urlpatterns = [
     path('',views.home, name='home'),

     # Authentication urls
     path('signup',views.signup, name="signup"),
     path('signin',views.signin, name="signin"),
     path('signout',views.signout, name="signout"),

     path('activate/<uidb64>/<token>', views.activate, name="activate"),

     path('forgot_password/', views.forgot_password, name='forgot_password'),
     path('reset_password/<uidb64>/<token>/', views.reset_password, name='reset_password'),

    # student dashboard urls
     path('dashboard/', views.student_dashboard, name='student_dashboard'),
     
     path('select_exam/', views.select_exam, name='select_exam'),
     path('quiz/<int:exam_id>/', views.quiz_view, name='quiz_view'),
     path('submit_exam/', views.submit_exam, name='submit_exam'),

     path('exam_results/', views.exam_results, name='exam_results'),
     #path('submit_response/', views.submit_response, name='submit_response'),
]
