from base64 import urlsafe_b64decode
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from Examination_portal import settings
from django.core.mail import send_mail, EmailMessage
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.utils.encoding import force_bytes, force_str 
from . tokens import generate_token
from . tokens import TokenGenerator
from django.contrib.auth.tokens import default_token_generator

from django.contrib.auth.decorators import login_required
from .models import UserExamResult, Quiz
from Superuser.models import Quiz
from Superuser.models import Option
from django.contrib.sessions.models import Session


# Create your views here.
def home(request):
    return render(request,"index.html")

def signup(request):

    if request.method == "POST":
        #username = request.POST.get('username')
        username = request.POST['username']
        fname = request.POST['fname']
        lname = request.POST['lname']
        email = request.POST['email']
        pass1 = request.POST['pass1']
        pass2 = request.POST['pass2']

        if User.objects.filter(username=username):
            messages.error(request, "username is already exit! please try some other username")
            return redirect('home')

        if User.objects.filter(email=email):
            messages.error(request, 'email already registered')
            return redirect('home')
        
        if len(username)>10:
            messages.error(request,"Username must be under 10 characters")

        if pass1 != pass2:
            messages.error(request, "password didn't match!")
            return redirect('signup')
        
        if not username.isalnum():
            messages.error(request, "Username must be alpha-numeric!")
            return redirect('home')

        myuser = User.objects.create_user(username, email, pass1)
        myuser.first_name = fname
        myuser.last_name = lname
        myuser.is_active = False

        myuser.save()

        messages.success(request, " YOUR ACCouts has been successfully created. we have sent you confirmation link please click on it !")

        #welcome mail
        subject = "welcome to suitewise -login !"
        message ="hello" + myuser.first_name + "!! \n" + "welcome to suitewise\n thank you for visiting our website please confirm you email \n \nthank you"
        from_email = settings.EMAIL_HOST_USER
        to_list = [myuser.email]
        send_mail(subject, message, from_email, to_list, fail_silently=True)


        #confiramation email

        current_site = get_current_site(request)
        email_subject = "confirm your email @ suitewise login"
        message = render_to_string('email_confirmation.html', {
            'name': myuser.first_name,
            'domain': current_site.domain,
            'uid': urlsafe_base64_encode(force_bytes(myuser.pk)),
            'token': generate_token.make_token(myuser)
        })
        email = EmailMessage(
            email_subject,
            message,
            settings.EMAIL_HOST_USER,
            [myuser.email],
        )
        email.fail_silently = True
        email.send()
        
        return redirect('signin')
    return render(request,"signup.html")

def signin(request):

    if request.method == 'POST':
        username = request.POST['username']
        pass1 = request.POST['pass1']

        user = authenticate(username=username, password=pass1)

        if user is not None and not user.is_superuser:
            login(request, user)
            fname = user.first_name
            return render(request, "dashboard/student_dashboard.html", {'fname':fname})
        else:
            messages.error(request, "Bad Credential!")
            return redirect('home')

    return render(request,"signin.html")

def signout(request):
    logout(request)
    messages.success(request, "Logged out successfully")
    return redirect('home')

def activate(request, uidb64, token):
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        myuser = User.objects.get(pk=uid)
    except(TypeError, ValueError, OverflowError, User.DoesNotExist):
        myuser = None

    if myuser is not None and generate_token.check_token(myuser, token):
        myuser.is_active = True
        myuser.save()
        login(request, myuser)
        messages.success(request, "now your account activated, kindly sign in")
        return redirect('signin')
    else:
        return render(request, 'activation_failed.html')


def forgot_password(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        try:
            user = User.objects.get(email=email)
        except User.DoesNotExist:
            messages.error(request, 'No user with this email address.')
            return redirect('forgot_password')

        # Generate a password reset token and send it via email
        token = default_token_generator.make_token(user)
        uid = urlsafe_base64_encode(force_bytes(user.pk))
        reset_url = f"/reset_password/{uid}/{token}/"

        # Get the current site's domain
        current_site = get_current_site(request)
        base_url = f"{request.scheme}://{current_site.domain}"

        message = f"Reset your password here: {base_url}{reset_url}"
        send_mail('Password Reset', message, settings.EMAIL_HOST_USER, [user.email])

        messages.success(request, 'Password reset email sent. Check your inbox.')
        return redirect('forgot_password')

    return render(request, 'forgot_password.html')


def reset_password(request, uidb64, token):
    if request.method == 'POST':
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
        if default_token_generator.check_token(user, token):
            password = request.POST.get('password')
            confirm_password = request.POST.get('confirm_password')
            if password == confirm_password:
                user.set_password(password)
                user.save()
                messages.success(request, 'Your password has been successfully reset.')
                return redirect('home')  # Redirect to login page after password reset
            else:
                messages.error(request, 'Password and confirm password do not match.')
                return render(request, 'reset_password.html', {'uidb64': uidb64, 'token': token})
        else:
            messages.error(request, 'Invalid token for password reset.')
            return render(request, 'reset_password.html', {'uidb64': uidb64, 'token': token})
            
    else:
        # Render the reset password form
        return render(request, 'reset_password.html', {'uidb64': uidb64, 'token': token})
     
@login_required    #this is decorator
def student_dashboard(request):
    return render(request, 'dashboard/student_dashboard.html')

from django.http import JsonResponse

@login_required
def select_exam(request):
    exams = Quiz.objects.all()  # Fetch all available exams from the database
    return render(request, 'select_exam.html', {'exams': exams})

@login_required
def quiz_view(request, exam_id):
    exam = get_object_or_404(Quiz, pk=exam_id)

    # Check if the user has already submitted the exam
    user_has_submitted_exam = UserExamResult.objects.filter(user=request.user, quiz=exam).exists()
    if user_has_submitted_exam:
        # Redirect the user to the exam results page
        return redirect('exam_results')
    questions = exam.question_set.all()  # Fetch questions related to the selected exam
    
    return render(request, 'quiz.html', {'exam': exam, 'questions': questions})

@login_required
def exam_results(request):
    user_results = UserExamResult.objects.filter(user=request.user)
    return render(request, 'exam_results.html', {'user_results': user_results})

from django.utils import timezone 

@login_required
def submit_exam(request):
    if request.method == 'POST':
        user = request.user
        exam_code = request.POST.get('exam_code')
        quiz = get_object_or_404(Quiz, exam_code=exam_code)
        questions = quiz.question_set.all()

        total_questions = questions.count()

        # Retrieve selected options from the POST data
        selected_options = {}
        for question in questions:
            option_id = request.POST.get(f'question_{question.id}', None)
            if option_id:
                selected_options[question.id] = int(option_id)
        
        # Calculate the score
        score = 0
        for question in questions:
            selected_option_id = selected_options.get(question.id)
            if selected_option_id is not None:
                # Check if the selected option is correct
                if Option.objects.filter(question=question, id=selected_option_id, is_correct=True).exists():
                    score += question.marks  # Increment score by question marks for correct answer

        # Save the user's exam result
        UserExamResult.objects.create(
            user=user,
            quiz=quiz,
            score=score,
            total_questions=total_questions,
            exam_code=quiz.exam_code,
            exam_title=quiz.title,
            selected_options=selected_options,
            submitted_at=timezone.now()
        )

         # Set session variable indicating exam has been submitted
        request.session['exam_submitted'] = True

        # Redirect to the exam results page
        messages.success(request, 'Your exam response has been submitted successfully.')
        return redirect('signout')

    # If request method is not POST, redirect to the home page or any other appropriate page
    return redirect('select_exam')

