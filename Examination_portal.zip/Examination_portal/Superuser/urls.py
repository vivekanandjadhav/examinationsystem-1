from django.urls import path
from . import views

#app_name = 'Superuser'

urlpatterns = [
    path('admin-signin/', views.admin_signin, name='admin_signin'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    
    path('admin/users/', views.admin_user_list, name='admin_user_list'),
    path('admin/users/<int:user_id>/', views.admin_user_detail, name='admin_user_detail'),
    path('admin/users/<int:user_id>/edit/', views.admin_user_edit, name='admin_user_edit'),
    path('admin/users/<int:user_id>/delete/', views.admin_user_delete, name='admin_user_delete'),

    
    path('create_exam/', views.create_exam, name='create_exam'),
    path('exam/<int:exam_id>/', views.exam_detail, name='exam_detail'),
    path('update_exam/<int:exam_id>/', views.update_exam, name='update_exam'),
    path('delete_exam/<int:exam_id>/', views.delete_exam, name='delete_exam'),
    path('exams/', views.exam_list, name='exam_list'),
    
    path('exam/<int:exam_id>/add_question/', views.add_question, name='add_question'),
    path('exam/<int:exam_id>/edit_question/<int:question_id>/', views.edit_question, name='edit_question'),
    path('exam/<int:exam_id>/delete_question/<int:question_id>/', views.delete_question, name='delete_question'),

    path('activate_exam/<int:exam_id>/', views.activate_exam, name='activate_exam'),
    path('deactivate_exam/<int:exam_id>/', views.deactivate_exam, name='deactivate_exam'),
    
    path('permission_list/', views.permission_list, name='permission_list'),
    path('Superuser/retake_exam/<int:user_id>/<str:exam_code>/', views.retake_exam, name='retake_exam'),

]
