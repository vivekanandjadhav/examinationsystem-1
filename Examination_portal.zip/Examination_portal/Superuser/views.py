from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth import authenticate, login
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User
from .models import Quiz, Question, Option

def admin_signin(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None and user.is_superuser:
            login(request, user)
            return redirect('admin_dashboard')  # Redirect to admin dashboard
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'Superuser/admin_signin.html')

@login_required
def admin_dashboard(request):
    return render(request, 'Superuser/admin_dashboard.html') 

@login_required
def admin_user_list(request):
    #users = User.objects.all()
    # Retrieve superusers and regular users
    superusers = User.objects.filter(is_superuser=True)
    regular_users = User.objects.filter(is_superuser=False)

    context = {
        'superusers': superusers,
        'regular_users': regular_users,
    }
    return render(request, 'Superuser/admin_user_list.html', context)
    #return render(request, 'Superuser/admin_user_list.html', {'users': users})

@login_required
def admin_user_detail(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    return render(request, 'Superuser/admin_user_detail.html', {'user': user})

@login_required
def admin_user_edit(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    if request.method == 'POST':
        # Process form data to update user
        user.username = request.POST.get('username')
        user.email = request.POST.get('email')
        user.first_name = request.POST.get('first_name')
        user.last_name = request.POST.get('last_name')

        user.save()  # Example: Save user updates
        messages.success(request, f"User {user.username} has been updated.")
        return redirect('admin_user_detail', user_id=user.id)
    return render(request, 'Superuser/admin_user_edit.html', {'user': user})

@login_required
def admin_user_delete(request, user_id):
    user = get_object_or_404(User, pk=user_id)
    if request.method == 'POST':
        if 'confirm_delete' in request.POST:
            user.delete()
            messages.success(request, f"User {user.username} has been deleted.")
            return redirect('admin_user_list')  # Redirect to user list or any other appropriate page
        else:
            return redirect('admin_user_list')  # Redirect back to user list without deleting

    return render(request, 'Superuser/admin_user_delete.html', {'user': user})

@login_required
def create_exam(request):
    if request.method == 'POST':
        # Process form data and create the exam
        # Save the exam details to the database
        new_exam = Quiz.objects.create(
            title=request.POST.get('title'),
            description=request.POST.get('description'),
            duration_minutes=request.POST.get('duration'),
            total_marks=request.POST.get('total_marks')
        )
        return redirect('exam_detail', exam_id=new_exam.id)  # Redirect to exam detail page
    else:
        return render(request, 'Superuser/create_exam.html')


@login_required
def exam_detail(request, exam_id):
    try:
        exam = get_object_or_404(Quiz, id=exam_id)
        questions = Question.objects.filter(exam=exam)
        total_questions = questions.count()  # Calculate total number of questions
        context = {'exam': exam, 'questions': questions, 'total_questions': total_questions}
        return render(request, 'Superuser/exam_detail.html', context)
    except Quiz.DoesNotExist:
        return render(request, 'Superuser/exam_not_found.html')
        
@login_required
def update_exam(request, exam_id):
    exam = get_object_or_404(Quiz, id=exam_id)
    if request.method == 'POST':
        # Process form data and update the exam
        exam.title = request.POST.get('title')
        exam.description = request.POST.get('description')
        exam.duration_minutes = request.POST.get('duration')
        exam.total_marks = request.POST.get('total_marks')
        exam.save()
        return redirect('exam_detail', exam_id=exam.id)  # Redirect to exam detail page
    else:
        return render(request, 'Superuser/update_exam.html', {'exam': exam})

@login_required
def delete_exam(request, exam_id):
    exam = get_object_or_404(Quiz, id=exam_id)
    if request.method == 'POST':
        exam.delete()
        return redirect('exam_list')  # Redirect to home page or any other appropriate page
    else:
        return render(request, 'Superuser/delete_exam.html', {'exam': exam})

@login_required
def exam_list(request):
    exams = Quiz.objects.all()
    return render(request, 'Superuser/exam_list.html', {'exams': exams})


@login_required
def add_question(request, exam_id):
    exam = get_object_or_404(Quiz, id=exam_id)
    options_range = range(1, 5)  # Default range for five options

    if request.method == 'POST':
        # Process form data and create the question
        question_text = request.POST.get('question_text')
        question_marks = request.POST.get('question_marks')
        question = Question.objects.create(exam=exam, text=question_text, marks=question_marks)
        # Create options for the question
        num_options = int(request.POST.get('num_options', 5))  # Default to 5 if not provided
        for i in range(1, num_options + 1):
            option_text = request.POST.get(f'option_{i}')
            is_correct = request.POST.get('correct_option') == str(i)
            Option.objects.create(question=question, text=option_text, is_correct=is_correct)
        return redirect('exam_detail', exam_id=exam_id)  # Redirect to exam detail page

    return render(request, 'Superuser/add_question.html', {'exam': exam, 'options_range': options_range})


@login_required
def edit_question(request, exam_id, question_id):
    exam = get_object_or_404(Quiz, id=exam_id)
    question = get_object_or_404(Question, id=question_id)

    if request.method == 'POST':
        # Process form data and update the question
        question.text = request.POST.get('question_text')
        question.marks = request.POST.get('question_marks')
        question.save()

        # Update options
        for option in question.option_set.all():
            option.text = request.POST.get(f'option_{option.id}')
            option.is_correct = option.id == int(request.POST.get('correct_option'))
            option.save()

        return redirect('exam_detail', exam_id=exam_id)

    # Prepare options range for the template
    options_range = range(1, question.option_set.count() + 1)

    return render(request, 'Superuser/edit_question.html', {'exam': exam, 'question': question, 'options_range': options_range})

@login_required
def delete_question(request, exam_id, question_id):
    question = get_object_or_404(Question, id=question_id)
    question.delete()
    return redirect('exam_detail', exam_id=exam_id)  # Redirect to exam detail page

from django.views.decorators.http import require_POST
@require_POST
def activate_exam(request, exam_id):
    exam = get_object_or_404(Quiz, id=exam_id)
    exam.is_active = True
    exam.save()
    return redirect('exam_list')

@require_POST
def deactivate_exam(request, exam_id):
    exam = get_object_or_404(Quiz, id=exam_id)
    exam.is_active = False
    exam.save()
    return redirect('exam_list')

from Exam.models import UserExamResult
from django.db.models import Count
@login_required
def permission_list(request):
    #users = User.objects.all()
    # Get users who have taken exams along with their exam counts
    users_with_exams = User.objects.annotate(num_exams=Count('userexamresult')).filter(num_exams__gt=0)
    return render(request, 'Superuser/user_permission.html', {'users':  users_with_exams})

@login_required
def retake_exam(request, user_id, exam_code):
    user = get_object_or_404(User, id=user_id)
    exam = get_object_or_404(Quiz, exam_code=exam_code)
    
    # Check if the user has already submitted the exam
    if UserExamResult.objects.filter(user=user, quiz=exam).exists():
        # If submitted, allow retaking the exam by deleting previous result
        UserExamResult.objects.filter(user=user, quiz=exam).delete()

    # Redirect to the exam page to retake it
    return redirect('permission_list')