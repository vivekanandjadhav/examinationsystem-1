from django import template

register = template.Library()

@register.filter
def get_option(options, index):
    try:
        return options[index - 1].text
    except IndexError:
        return ''