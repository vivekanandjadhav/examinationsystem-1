from django.db import models

# Create your models here.
import uuid

class Quiz(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    duration_minutes = models.PositiveIntegerField(default=30)  # Duration in minutes
    exam_code = models.CharField(max_length=10, unique=True, editable=False)  # Exam code for each quiz
    total_marks = models.PositiveIntegerField(default=100)  # Total marks for the quiz
    is_active = models.BooleanField(default=False) 
    
    def __str__(self):
        return self.title

    def save(self, *args, **kwargs):
        if not self.exam_code:  # Only generate exam code if not provided
            self.exam_code = str(uuid.uuid4().hex[:6].upper())  # Generate a unique random code
        super().save(*args, **kwargs)

class Question(models.Model):
    exam = models.ForeignKey(Quiz, on_delete=models.CASCADE)
    text = models.TextField()
    marks = models.PositiveIntegerField(default=1)  # Marks for the question

    def __str__(self):
        return self.text

class Option(models.Model):
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    text = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return self.text