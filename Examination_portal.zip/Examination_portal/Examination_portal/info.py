EMAIL_USE_TLS = True
EMAIL_HOST = 'smtp.gmail.com'
EMAIL_HOST_USER = 'vivekanandjadhav95@gmail.com'
EMAIL_HOST_PASSWORD = 'iqvr prmt euib wfyo'
EMAIL_PORT =587